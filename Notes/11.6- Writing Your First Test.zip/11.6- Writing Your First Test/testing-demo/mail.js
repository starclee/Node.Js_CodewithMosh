
module.exports.send = function(to, subject) {
  console.log('Sending an email...');
}